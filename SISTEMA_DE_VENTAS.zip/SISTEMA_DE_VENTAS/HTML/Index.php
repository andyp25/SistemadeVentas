<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="./Index.html">Inicio</a></li>
                <li><a href="./Productos.html">Productos</a></li>
                <li><a href="./Ventas.html">Ventas</a></li>
                <li><a href="./Usuario.html">Clientes</a></li>
            </ul>
        </nav>
    </header>
    <aside>
        <h2>Categorias</h2>
        <?php
        
        ?>
    </aside>
    <main>
       
        <footer>
            <p>&copy; 2024 tienda Online de ropa</p>
        </footer>

    </main>
</body>
</html>